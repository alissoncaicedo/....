package restaurante.producto.entidad;

import restaurante.dominio.ValidadorArgumento;

import javax.persistence.Entity;
import java.math.BigDecimal;

@Entity
public class Producto {
    private final Long id;
    private final String nombre;
    private final String categoria;
    private final BigDecimal valor;

    private Producto(Long id, String nombre, String categoria, BigDecimal valor) {
        this.id = id;
        this.nombre = nombre;
        this.categoria = categoria;
        this.valor = valor;
    }

    public static Producto reconstruir(Long id, String nombre, String categoria, BigDecimal valor) {
        ValidadorArgumento.validarObligatorio(id, "El id del producto es requerido");
        ValidadorArgumento.validarObligatorio(nombre, "El nombre del producto es requerido");
        ValidadorArgumento.validarObligatorio(categoria, "Aplica la categoria es requerido");
        ValidadorArgumento.validarObligatorio(valor, "Valor es requerido para el producto");
        return new Producto(id, nombre, categoria, valor);

    }

    public String getNombre() {
        return nombre;
    }

    public Long getId() {
        return id;
    }

    public String getCategoria() {
        return categoria;
    }

    public BigDecimal getValor() {
        return valor;
    }
}
