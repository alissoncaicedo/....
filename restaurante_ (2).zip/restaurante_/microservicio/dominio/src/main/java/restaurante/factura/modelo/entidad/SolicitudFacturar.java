package restaurante.factura.modelo.entidad;


import lombok.AllArgsConstructor;
import lombok.Getter;
import restaurante.usuario.entidad.Usuario;

import java.util.List;

@Getter
@AllArgsConstructor
public class SolicitudFacturar {

    private final Usuario usuario;
    private final List<ProductoFacturar> productosFacturar;


}
