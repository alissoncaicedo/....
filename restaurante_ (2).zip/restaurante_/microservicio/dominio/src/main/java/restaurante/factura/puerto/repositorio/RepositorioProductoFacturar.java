package restaurante.factura.puerto.repositorio;

import restaurante.factura.modelo.entidad.Factura;
import restaurante.factura.modelo.entidad.ProductoFacturar;

import java.util.List;

public interface RepositorioProductoFacturar {

    void guardarPorFactura(Factura factura, Long idFactura);

    List<ProductoFacturar> obtenerPorFactura(Long idFactura);
}
