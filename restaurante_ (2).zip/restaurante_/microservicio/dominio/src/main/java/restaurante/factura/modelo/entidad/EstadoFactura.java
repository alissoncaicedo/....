package restaurante.factura.modelo.entidad;

public enum EstadoFactura {
    ANULADA, ACTIVA
}
