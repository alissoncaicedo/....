package restaurante.usuario.entidad;


public enum TipoDeUsuario  {

    EMPLEADO,
    ADMINISTRADOR,
    CLIENTE
}
