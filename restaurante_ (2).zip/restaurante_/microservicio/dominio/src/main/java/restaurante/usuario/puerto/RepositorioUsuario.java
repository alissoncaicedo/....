package restaurante.usuario.puerto;

import restaurante.usuario.entidad.Usuario;

public interface RepositorioUsuario {

    Usuario obtener(Long id);
}
