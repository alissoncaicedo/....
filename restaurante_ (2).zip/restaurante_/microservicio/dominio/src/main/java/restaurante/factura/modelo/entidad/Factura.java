package restaurante.factura.modelo.entidad;

import restaurante.dominio.ValidadorArgumento;
import restaurante.dominio.excepcion.ExcepcionValorInvalido;
import restaurante.usuario.entidad.Usuario;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Factura {

    private Long id;
    private Usuario usuario;
    private List<ProductoFacturar> productosFacturar;
    private BigDecimal valorTotal;
    private EstadoFactura estado;

    private Factura(Usuario usuario, List<ProductoFacturar> productosFacturar) {
        this.usuario = usuario;
        this.productosFacturar = new ArrayList<>(productosFacturar);
        this.valorTotal = calcularvalorTotal(productosFacturar);
        this.estado = EstadoFactura.ACTIVA;
    }


    private BigDecimal calcularvalorTotal(List<ProductoFacturar> productosFacturar) {
        return productosFacturar.stream()
                .map(ProductoFacturar::calcularTotalConIva)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }


    public Usuario getUsuario() {
        return this.usuario;
    }

    public List<ProductoFacturar> getProductos() {
        return Collections.unmodifiableList(productosFacturar);
    }

    public BigDecimal getValorTotal() {
        return valorTotal;
    }

    public Long getId() {
        return id;
    }

    public static Factura crear(SolicitudFacturar solicitudFacturar) {
        ValidadorArgumento.validarObligatorio(solicitudFacturar.getUsuario(), "El usuario es requerido para facturar");
        ValidadorArgumento.validarNoVacio(solicitudFacturar.getProductosFacturar(), "No se puede crear una factura sin productos");
        return new Factura(solicitudFacturar.getUsuario(), solicitudFacturar.getProductosFacturar());
    }

    public static Factura reconstruir(Long id, Usuario usuario, List<ProductoFacturar> productosFacturar, BigDecimal valorTotal, EstadoFactura estadoFactura) {
        ValidadorArgumento.validarObligatorio(usuario, "El usuario es requerido para facturar");
        ValidadorArgumento.validarNoVacio(productosFacturar, "No se puede crear una factura sin productos");
        ValidadorArgumento.validarObligatorio(id, "El id es requerido");
        if (valorTotal.compareTo(BigDecimal.ZERO) <= 0) {
            throw new ExcepcionValorInvalido("El total no puede ser menor a cero");
        }
        return new Factura( usuario, productosFacturar);
    }


    public Boolean esAnulada() {
        return this.estado.equals(EstadoFactura.ANULADA);
    }

    public boolean esActiva() {
        return this.estado.equals(EstadoFactura.ACTIVA);
    }

    public EstadoFactura getEstado() {
        return estado;
    }
}
