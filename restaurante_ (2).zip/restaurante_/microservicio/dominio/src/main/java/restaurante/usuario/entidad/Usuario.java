package restaurante.usuario.entidad;

import restaurante.dominio.ValidadorArgumento;

import javax.persistence.*;

@Entity
@Table(name = "usuarios")
public class Usuario {
        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private long id;

        @Column
        private String nombre;

        @Column
        private TipoDeUsuario tipoDeUsuario;

    public  Usuario (long id, String nombre, TipoDeUsuario tipoDeUsuario) {
        this.id = id;
        this.nombre = nombre;
        this.tipoDeUsuario = tipoDeUsuario;
    }
    public Usuario crearEmpleado(long id, String nombre, TipoDeUsuario tipoDeUsuario) {
        ValidadorArgumento.validarObligatorio(tipoDeUsuario, "Tipo de cliente es requerido");
        ValidadorArgumento.validarObligatorio(nombre, "Nombre del cliente es requerido");
        ValidadorArgumento.validarObligatorio(id, "Id del cliente es requerido");
        return new Usuario(id, nombre, tipoDeUsuario);
    }

    public long getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public TipoDeUsuario getTipoDeUsuario() {
        return tipoDeUsuario;
    }
}
