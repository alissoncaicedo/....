package restaurante.producto.puerto;

import restaurante.producto.entidad.Producto;

public interface RepositorioProducto {

    Producto obtener(Long id);
}
