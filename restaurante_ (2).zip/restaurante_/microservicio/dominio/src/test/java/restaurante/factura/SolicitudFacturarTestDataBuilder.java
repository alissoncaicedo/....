package restaurante.factura;

import restaurante.cliente.entidad.Cliente;
import restaurante.factura.modelo.entidad.ProductoFacturar;
import restaurante.factura.modelo.entidad.SolicitudFacturar;
import restaurante.usuario.entidad.Usuario;

import java.util.ArrayList;
import java.util.List;

public class SolicitudFacturarTestDataBuilder {

    private List<ProductoFacturar> productosFacturar;
    private Usuario usuario;

    public SolicitudFacturarTestDataBuilder() {
        this.productosFacturar = new ArrayList<>();
    }

    public SolicitudFacturarTestDataBuilder conProductoFacturar(ProductoFacturar productoFacturar) {
        this.productosFacturar.add(productoFacturar);
        return this;
    }

    public SolicitudFacturarTestDataBuilder conProductosFacturar(List<ProductoFacturar> productosFacturar) {
        this.productosFacturar = productosFacturar;
        return this;
    }

    public SolicitudFacturarTestDataBuilder conCliente(Usuario cliente) {
        this.usuario = cliente;
        return this;
    }

    public SolicitudFacturar build() {
        return new SolicitudFacturar(usuario, productosFacturar);
    }

}
