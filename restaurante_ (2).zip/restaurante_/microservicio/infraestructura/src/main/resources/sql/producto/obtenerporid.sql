select  id, nombre, aplica_iva, valor
from producto
where id = :id