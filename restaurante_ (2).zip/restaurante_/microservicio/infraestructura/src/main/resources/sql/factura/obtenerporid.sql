select  id, id_cliente, valor_total, estado
from factura
where id = :id