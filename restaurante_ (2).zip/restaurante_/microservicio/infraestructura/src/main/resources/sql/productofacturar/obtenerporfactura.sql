select  id, id_producto, cantidad
from producto_facturar
where id_factura = :id_factura