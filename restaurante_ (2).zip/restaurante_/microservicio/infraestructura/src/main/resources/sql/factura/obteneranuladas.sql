select  id, valor_total, estado
from factura
where estado = 'ANULADA'