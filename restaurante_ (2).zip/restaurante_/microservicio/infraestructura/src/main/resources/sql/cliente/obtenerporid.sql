select  id, nombre, tipo_cliente
from cliente
where id = :id