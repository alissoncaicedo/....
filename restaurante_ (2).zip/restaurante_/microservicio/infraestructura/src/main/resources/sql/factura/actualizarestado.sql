update factura
set estado = :estado
where id = :id