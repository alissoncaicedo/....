insert into producto_facturar( id_factura,
                     id_producto,
                     cantidad ) values(:id_factura, :id_producto, :cantidad)