package restaurante.factura.controlador;

import restaurante.factura.comando.ComandoProductoFacturar;
import restaurante.factura.comando.ComandoSolicitudFacturar;

import java.util.ArrayList;
import java.util.List;


public class ComandoFacturarTestDataBuilder {

    private Long idCliente;
    private List<ComandoProductoFacturar> comandoProductosFacturar;

    public ComandoFacturarTestDataBuilder() {
        this.comandoProductosFacturar = new ArrayList<>();
    }

    public ComandoFacturarTestDataBuilder crearPorDefecto() {
        this.idCliente = 1l;
        this.comandoProductosFacturar.add(new ComandoProductoFacturar());
        this.comandoProductosFacturar.add(new ComandoProductoFacturar());
        return this;

    }

    public ComandoSolicitudFacturar build() {
        return new ComandoSolicitudFacturar(this.idCliente, comandoProductosFacturar);
    }
}
