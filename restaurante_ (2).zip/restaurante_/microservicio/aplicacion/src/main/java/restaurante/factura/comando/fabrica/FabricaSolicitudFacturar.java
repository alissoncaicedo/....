package restaurante.factura.comando.fabrica;

import restaurante.factura.comando.ComandoProductoFacturar;
import restaurante.factura.comando.ComandoSolicitudFacturar;
import restaurante.factura.modelo.entidad.ProductoFacturar;
import restaurante.factura.modelo.entidad.SolicitudFacturar;
import restaurante.producto.puerto.RepositorioProducto;
import org.springframework.stereotype.Component;
import restaurante.usuario.puerto.RepositorioUsuario;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class FabricaSolicitudFacturar {

    private final RepositorioUsuario repositorioUsuario;
    private final RepositorioProducto repositorioProducto;

    public FabricaSolicitudFacturar(RepositorioUsuario repositorioUsuario, RepositorioProducto repositorioProducto) {
        this.repositorioUsuario = repositorioUsuario;
        this.repositorioProducto = repositorioProducto;
    }

    public SolicitudFacturar crear(ComandoSolicitudFacturar comandoSolicitudFacturar) {
        return new SolicitudFacturar(repositorioUsuario.obtener(comandoSolicitudFacturar.getIdUsuario()),
                obtenerProductos(comandoSolicitudFacturar.getComandoProductosFacturar())
        );
    }

    private List<ProductoFacturar> obtenerProductos(List<ComandoProductoFacturar> comandoProductosFacturar) {
        return comandoProductosFacturar.stream().map(comandoProducto ->
                        ProductoFacturar.crear(
                                comandoProducto.getCategoria(),
                                repositorioProducto.obtener(comandoProducto.getIdProducto())))
                                .collect(Collectors.toList());
    }
}
