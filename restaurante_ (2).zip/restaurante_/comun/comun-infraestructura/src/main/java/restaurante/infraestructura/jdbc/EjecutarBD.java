package restaurante.infraestructura.jdbc;

public interface EjecutarBD<T> {
    T ejecutar();
}